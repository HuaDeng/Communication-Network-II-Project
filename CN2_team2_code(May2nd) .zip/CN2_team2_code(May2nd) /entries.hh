#include <click/vector.hh>

struct TableEntry{
     int cost;
     Vector<int> nextHop;
};
